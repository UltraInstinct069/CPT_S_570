#!/bin/bash

echo 'Running code for Naive Bayes'
python fortune_cookie.py

echo 'finish!'