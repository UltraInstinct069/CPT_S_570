Python version: 3.9.12

Steps to run the code:
1. Place data files into the data folder.
2. run 'run_code.sh' script.