#!/bin/bash

echo 'Running code for 5.1 Binary Classification'
python q51.py
echo 'Running code for 5.2 Multi-Class Classification'
python q52.py

echo 'finish!'