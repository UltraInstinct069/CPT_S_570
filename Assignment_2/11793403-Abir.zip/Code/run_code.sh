#!/bin/bash

echo 'Running code for question 1 SVM'
python q1.py
echo 'Running code for question 2 Kernalized Perceptron'
python q2.py
echo 'Running code for question 3 ID3'
python q3.py

echo 'finish!'