Python version: 3.9.12

Steps to run the code:
1. Place data files into the data folder.
2. run 'run_code.sh' script.

Notes:
1. For question no 1, I could not able to run experiments for c=1000,10000 as it was taking longer time to execute and my laptop got slowed. Colab also got disconnected after certain time.
2. The graph plotting codes may not available for all code because it took a lot of time to perform all experiments at once. So I divided many of the experiments and run them on different instaces (Colab, personal laptop and lab computer) and merged the result to generate the graph. However, detailed output will be printed on the console for all the experiments.